package com.efrobot.capturing;

/**
 * Created by jqr111 on 2016/8/15.
 * 常量类
 */
public class AndroidConstants {

    /**
     * 上传照片的地址
     */
//    public static String UPLOAD_URL = "http://192.168.20.163:8081/v1/word/form/pic";//内网访问地址
   public static String UPLOAD_URL = "http://test.sypdl.com:8081/v1/word/form/pic";//外网访问地址
}
