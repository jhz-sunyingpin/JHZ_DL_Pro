package com.efrobot.capturing;

/**
 * Created by wym on 2016/2/18.邮箱：wuyamin@ren001.com
 */
public interface Onfinish {
    void onFinish();
}
