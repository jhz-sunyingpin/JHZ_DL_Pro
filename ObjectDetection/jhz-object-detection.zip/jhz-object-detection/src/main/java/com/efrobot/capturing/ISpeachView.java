package com.efrobot.capturing;


import com.efrobot.library.mvp.view.UiView;

/**
 * Created by xfk on 2015/5/18.
 * 父类方法
 */
public interface ISpeachView extends UiView {

}
